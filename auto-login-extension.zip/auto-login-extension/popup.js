const usernameInput = document.getElementById("username");
const passwordInput = document.getElementById("password");
const statusText = document.getElementById("status");

// 🔹 Load saved data when popup opens
chrome.storage.local.get(["username", "password"], (data) => {
    if (data.username) usernameInput.value = data.username;
    if (data.password) passwordInput.value = data.password;
});

// 🔹 Save button
document.getElementById("save").addEventListener("click", () => {
    const username = usernameInput.value;
    const password = passwordInput.value;

    chrome.storage.local.set({ username, password }, () => {
        statusText.textContent = "Saved successfully!";
        
        setTimeout(() => {
            statusText.textContent = "";
        }, 2000);
    });
});

// 🔹 Show / Hide password
document.getElementById("togglePass").addEventListener("click", () => {
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        togglePass.textContent = "Hide";
    } else {
        passwordInput.type = "password";
        togglePass.textContent = "Show";
    }
});