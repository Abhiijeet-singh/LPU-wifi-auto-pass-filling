window.addEventListener("load", () => {

    // Select fields (update if needed using inspect)
    const usernameField = document.querySelector("input[name='username']");
    const passwordField = document.querySelector("input[name='password']");
    const loginButton = document.querySelector("button[type='submit']");
    const checkbox = document.querySelector("input[type='checkbox']");

    chrome.storage.local.get(["username", "password"], (data) => {

        if (usernameField && passwordField) {

            let username = data.username || "";
            let password = data.password || "";

            // 🔥 Remove @lpu.com if present
            username = username.replace("@lpu.com", "");

            // Fill fields
            usernameField.value = username;
            passwordField.value = password;

            console.log("Filled credentials");

            // ✅ Check Terms & Conditions
            if (checkbox && !checkbox.checked) {
                checkbox.click();
                console.log("Checkbox checked");
            }

            // 🚀 Click login
            if (loginButton) {
                setTimeout(() => {
                    loginButton.click();
                }, 500); // small delay for safety
            }
        } else {
            console.log("Fields not found");
        }
    });
});